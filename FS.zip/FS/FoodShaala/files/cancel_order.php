<?php
include "connection.php";
    $id=$_GET['id'];
	$status = "Cancelled order";
	$sql1 = "update orders SET status = '$status' WHERE id = '$id'";
	$result1 = $conn->query($sql1);
?>